# cardBot
A Discord bot that allows you to play card games through Discord chat!
The bot currently facilitates Texas Hold 'Em Poker and Blackjack.
To learn how to use the bot, type $help in your Discord channel.
